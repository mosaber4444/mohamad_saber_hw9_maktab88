let Students = [{
        "name": "adsf",
        "Age": "15",
        "RollNumber": "123",
        "Marks": "99",

    }, {
        "name": "asdf",
        "Age": "Am",
        "RollNumber": "223",
        "Marks": "69",
    },
        {
            "name": "Vivek",
            "Age": "Am",
            "RollNumber": "253",
            "Marks": "89",
        },
    ]


let newArray = Students.filter(function (el) {
        return el.name == 'Am' || el.Age == 'Am' ||el.RollNumber == 'Am' ||el.Marks == 'Am' ;

    }
)





;
console.log(newArray);