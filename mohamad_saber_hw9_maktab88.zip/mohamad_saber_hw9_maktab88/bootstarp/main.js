let table = $('#table');
let search = $('#search');
let target = $('#target');

function renderUser(arr) {
    table.empty()
    let text = '';
    for (let i = 0; i < arr.length; i++) {
        if (i + 1 % 3 === 0 || i === 0) {
            text += `<tr>`
        }
        text += `<td>
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="${arr[i]['avatar']}" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">${arr[i]['first_name']} ${arr[i]['last_name']}</h5>
                        <p class="card-text">${arr[i]['first_name']} ${arr[i]['last_name']} is maktab88 user by Uid of ${arr[i]['id']}            
                            <a>${arr[i]['email']}</a>
                        </p>
                    </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">UId :${arr[i]['id']} </li>
                    <li class="list-group-item">email:${arr[i]['email']}</li>
                </ul>
                <div class="card-body">
                    <a href="#" class="btn btn-primary">profile</a>
                </div>
            </div>  
            </td>      
        `
        if ((i + 1) % 3 === 0) {
            text += '</tr>';
        }
    }
    table.append(text);
}

renderUser(users);

function searching() {
    if (target.val()==''){
        return renderUser(users)
    }
    let newArray = users.filter(function (el) {
            return el.id == target.val() || el.email == target.val() || el.first_name == target.val()|| el.last_name == target.val() ;
        }
    )
    console.log(target.val())
    console.log(newArray)
    renderUser(newArray)
}

