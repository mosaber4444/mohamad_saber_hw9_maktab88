let table = $("#table");
let isSelect = false;
let selectRow;

function addProperty() {
    let arrayProperty;
    arrayProperty = Object.keys(userData[0]);
    table.append("<caption>maktab88</caption>");
    table.append("<thead>");
    table.append("<tr>");
    table.append(`<th>rows</th>`)
    for (let i = 0; i < arrayProperty.length; i++) {
        table.append(`<th onclick="sortU(this.innerText)">${arrayProperty[i]} </th>`);
    }
    table.append('<th>delete</th>')
    table.append("</tr>");
    table.append("</thead>");
}

function addValue() {
    let arrayValue;
    for (let i = 0; i < userData.length; i++) {
        arrayValue = Object.values(userData[i]);
        table.append('<tr onclick="editObject()">');
        table.append(`<td>${i + 1}</td>`);
        if (isSelect) {
            if (i === selectRow) {
                for (let i = 0; i < arrayValue.length; i++) {
                    table.append(`<td><input id="${i}" value="${arrayValue[i]}"></td>`);
                }
                table.append(`<td ><button onclick="deleteUserDAta(${i})">delete</button><span><button onclick="editObject(${i})">edit</button></span></td>`);
            }
            if (isSelect && selectRow === i) {
                i++;
                arrayValue = Object.values(userData[i]);
                table.append('<tr>');
                table.append(`<td>${i + 1}</td>`);
            }
        }
        for (let indexRowsValue = 0; indexRowsValue < arrayValue.length; indexRowsValue++) {
            table.append(`<td>${arrayValue[indexRowsValue]}</td>`);
        }
        table.append(`<td ><button onclick="deleteUserDAta(${i})">delete</button><span><button id="editButton" onclick="editObject(${i})">edit</button></span></td>`);
        table.append('</tr>');
    }
}

function readUserData() {
    addProperty();
    addValue();
}

function dynamicSort(property) {
    let sortOrder = 1;
    if (property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return (a, b) => {
        let result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}

function sortU(property) {
    console.log(property);
    userData.sort(dynamicSort(property));
    $('#table').empty();
    readUserData();
}

function deleteUserDAta(index) {
    userData.splice(index, 1);
    $('#table').empty();
    readUserData();
}

function addObject() {
    let objEdited = {
        uid: $("#uid").val(),
        firstName: $("#firstName").val(),
        lastName: $("#lastName").val(),
        city: $("#city").val(),
        personalCode: $("#personalCode").val(),
        phoneNumber: $("#phoneNumber").val(),
        position: $("#position").val(),
    }
    //validation
    for (let i = 0; i < userData.length; i++) {
        if (parseInt(objEdited['uid']) == userData[i]["uid"]) {
            alert(`${objEdited['uid']} not a uniq!!!!!`)
            return;
        }
    }
    if (parseInt(objEdited['uid']) != objEdited['uid']) {
        alert(`${objEdited['uid']} not a number!!!!!!!!`);
        return;
    }
    if (objEdited['uid'] === "" || objEdited['firstName'] === "" || objEdited['lastName'] === "" || objEdited['city'] === "" || objEdited['personalCode'] === "" || objEdited['phoneNumber'] === "" || objEdited['position'] === "") {
        alert('You need to fill the fields ')
        return;
    }
    //end validation
    userData.push(objEdited);
    $('#table').empty();
    readUserData();
}

function editObject(index) {
    let obj = {
        uid: $('#0').val(),
        firstName: $('#1').val(),
        lastName: $('#2').val(),
        city: $('#3').val(),
        personalCode: $('#4').val(),
        phoneNumber: $('#5').val(),
        position: $('#6').val(),
    }
    if (!isSelect) {
        isSelect = true;
        selectRow = index;
        $('#table').empty();
        readUserData();
    } else {
        isSelect = false;
        // validation
        for (let i = 0; i < userData.length; i++) {
            if (index === i ){
                i++; //jump a self uniq check
            }
            if (parseInt(obj['uid']) == userData[i]["uid"]) {
                alert(`${obj['uid']} not a uniq!!!!!`)
                isSelect = true;
                return;
            }
        }
        if (parseInt(obj['uid']) != obj['uid']) {
            alert(`${obj['uid']} not a number!!!!!!!!`);
            isSelect = true;
            return;
        }
        if (obj['uid'] === "" || obj['firstName'] === '' || obj['lastName'] === "" || obj['city'] === "" || obj['personalCode'] === "" || obj['phoneNumber'] === "" || obj['position'] === "") {
            alert('You need to fill the fields ')
            return;
        }
        //end validation
        userData[index] = obj ;
        $('#table').empty();
        readUserData();
    }
}

readUserData();




