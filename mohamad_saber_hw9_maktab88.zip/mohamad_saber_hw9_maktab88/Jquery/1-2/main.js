let a = $('#a');
text = 'adsf'

a.css({"background-color": "yellow", "font-size": "200%"});

a.hover(function () {
    a.css({"background-color": "red", "font-size": "200%"});
});

a.on("mouseleave", function () {
    console.log('birron')
    a.css({"background-color": "yellow", "font-size": "200%"});
});
