let a = $('#a');
text = 'adsf'

a.css({"background-color": "yellow", "font-size": "200%"});

a.click(function () {
    text += text
    a.html(text);
});